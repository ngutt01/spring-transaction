package com.sathya.dao;

import java.util.List;
import java.util.Map;

public interface IEmpDao {
	List<Map<String,Object>>  getEmployees();
}
